import Model from './model.js';

window.onload = function() {
  // fill me with relevant code
};
