# Homework 1 -- Fake Stack Overflow with HTML/CSS/JavaScript

**Remember to list your contribution in the sections shown below before the due date.**

## Team Member 1 contribution

## Team Member 2 contribution
